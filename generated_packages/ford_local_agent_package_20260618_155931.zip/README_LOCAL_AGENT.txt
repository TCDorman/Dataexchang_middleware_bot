LOCAL CUSTOMER AGENT PACKAGE

Customer:
Ford

Purpose:
This local runner watches the customer's input folder, converts incoming files into
Modula WMS XML, imports ordini/articoli through the ModulaRuntimeAgent, then watches
for WMS export ordini files and converts them back into the customer's original format.

Run once:
python run_ford_local_agent.py --once

Run continuously:
python run_ford_local_agent.py --watch

Run continuously with custom polling:
python run_ford_local_agent.py --watch --poll-seconds 10

Folders:
Customer Input:
data/customer_input/ford

WMS Ordini Import:
data/wms_imports/ordini

WMS Articoli Import:
data/wms_imports/articoli

WMS Export Ordini:
data/wms_exports

Customer Output:
data/customer_exports/ford

Logs:
generated_integrations\ford\logs

Customer Profile:
configs/customers/ford_profile.json